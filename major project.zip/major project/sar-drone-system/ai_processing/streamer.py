"""Combined AI detection + video streamer. Sends frames and detections to backend."""
import base64
import json
import logging
import os
import sys
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

import cv2
import requests

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ai_processing.detector import load_model, run_inference, draw_detections

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")
FRAME_INTERVAL = 1.0 / 10  # 10 fps to dashboard
ALERT_COOLDOWN = 5.0


def stream_loop(camera_index: int = 0, conf_threshold: float = 0.5):
    """Run detection and stream frames + alerts to backend."""
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        logger.error(f"Cannot open camera {camera_index}")
        return

    load_model()
    last_alert = 0
    last_frame_sent = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.1)
                continue

            results = run_inference(frame, conf=conf_threshold)
            frame, detections = draw_detections(frame, results, conf_threshold)
            if detections:
                logger.info(f"Person detected: {len(detections)} in frame")

            now = time.time()

            # Send frame to backend (throttled)
            if now - last_frame_sent >= FRAME_INTERVAL:
                try:
                    _, buf = cv2.imencode(".jpg", frame)
                    b64 = base64.b64encode(buf).decode()
                    r = requests.post(
                        f"{BACKEND_URL}/api/frame",
                        json={"frame": b64, "detections": detections},
                        timeout=2,
                    )
                    if r.status_code == 200:
                        last_frame_sent = now
                except Exception as e:
                    logger.debug(f"Frame POST: {e}")

            # Send alert if person detected
            if detections and now - last_alert > ALERT_COOLDOWN:
                last_alert = now
                alert = {
                    "id": str(uuid.uuid4()),
                    "type": "victim_detected",
                    "severity": "high",
                    "message": f"Person detected - {len(detections)} victim(s) in frame",
                    "detections": detections,
                    "timestamp": datetime.utcnow().isoformat(),
                }
                try:
                    r = requests.get(f"{BACKEND_URL}/api/telemetry", timeout=2)
                    if r.status_code == 200:
                        j = r.json()
                        t = j.get("telemetry")
                        if t and t.get("latitude") is not None and t.get("longitude") is not None:
                            alert["latitude"] = t["latitude"]
                            alert["longitude"] = t["longitude"]
                            alert["location"] = f"{t['latitude']:.5f}, {t['longitude']:.5f}"
                except Exception:
                    pass
                try:
                    requests.post(f"{BACKEND_URL}/api/alert", json=alert, timeout=2)
                except Exception as e:
                    logger.debug(f"Alert POST: {e}")

            time.sleep(0.03)
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--camera", type=int, default=0)
    p.add_argument("--conf", type=float, default=0.35, help="Detection confidence (lower = more detections, default 0.35)")
    p.add_argument("--backend", default="http://localhost:8000")
    args = p.parse_args()
    os.environ["BACKEND_URL"] = args.backend
    stream_loop(camera_index=args.camera, conf_threshold=args.conf)
