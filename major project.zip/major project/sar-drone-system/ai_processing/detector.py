"""YOLOv5 person detection - uses ultralytics/yolov5 (https://github.com/ultralytics/yolov5)."""
import base64
import json
import logging
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Use YOLOv5 from ultralytics/yolov5 (torch.hub)
USE_YOLOV5 = True
_model = None


def load_model(weights: str = None):
    """Load YOLOv5 from https://github.com/ultralytics/yolov5 via torch.hub."""
    global _model
    if _model is not None:
        return _model
    try:
        import torch
        # yolov5n = nano (fastest), yolov5s = small, yolov5m = medium
        model_name = weights or "yolov5n"
        if model_name.endswith(".pt"):
            _model = torch.hub.load("ultralytics/yolov5", "custom", path=model_name, force_reload=False)
        else:
            _model = torch.hub.load("ultralytics/yolov5", model_name, pretrained=True)
        _model.conf = 0.35
        _model.classes = [0]  # 0 = person in COCO
        logger.info(f"YOLOv5 loaded: {model_name}")
        return _model
    except Exception as e:
        logger.error(f"YOLOv5 load failed: {e}")
        raise


def run_inference(frame, conf=0.35):
    """Run YOLOv5 inference. Returns results object. Frame: BGR numpy from OpenCV."""
    global _model
    if _model is None:
        load_model()
    _model.conf = conf
    results = _model(frame)
    return results


def draw_detections(frame, results, conf_threshold=0.35):
    """Draw bounding boxes on frame and return list of detections.
    YOLOv5 results: results.xyxy[0] = [x1, y1, x2, y2, conf, class]"""
    detections = []
    if results is None:
        return frame, detections
    try:
        # YOLOv5 format: tensor (N, 6) - x1, y1, x2, y2, confidence, class_id
        pred = results.xyxy[0]
        if pred is None or len(pred) == 0:
            return frame, detections
        pred = pred.cpu().numpy()
        for *xyxy, conf, cls in pred:
            cls = int(cls)
            if cls != 0:  # 0 = person
                continue
            if conf < conf_threshold:
                continue
            x1, y1, x2, y2 = map(int, xyxy)
            # Green = good (high confidence), Red = danger (low confidence)
            is_danger = conf < 0.55
            color = (0, 0, 255) if is_danger else (0, 255, 0)  # BGR: red or green
            label = "DANGER" if is_danger else "OK"
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(
                frame, f"{label} {conf:.2f}",
                (x1, max(y1 - 5, 0)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2,
            )
            detections.append({
                "label": "person",
                "confidence": float(conf),
                "bbox": [x1, y1, x2, y2],
                "status": "danger" if is_danger else "good",
            })
    except Exception as e:
        logger.debug(f"Draw error: {e}")
    return frame, detections


def post_alert(alert: dict):
    """Send alert to backend via HTTP."""
    try:
        import urllib.request
        url = os.getenv("BACKEND_URL", "http://localhost:8000")
        req = urllib.request.Request(
            f"{url}/api/alert",
            data=json.dumps(alert, default=str).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=2) as r:
            pass
    except Exception as e:
        logger.debug(f"Alert POST failed: {e}")


def run_detection_loop(camera_index: int = 0, conf_threshold: float = 0.35, emit_alerts: bool = True):
    """Run continuous YOLOv5 detection on camera."""
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        logger.error(f"Cannot open camera {camera_index}")
        return
    load_model()
    last_alert_time = 0
    import time
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            results = run_inference(frame, conf=conf_threshold)
            frame, detections = draw_detections(frame, results, conf_threshold)
            if detections:
                logger.info(f"Person detected: {len(detections)}")
                if emit_alerts and (time.time() - last_alert_time) > 5:
                    last_alert_time = time.time()
                    post_alert({
                        "id": str(uuid.uuid4()),
                        "type": "victim_detected",
                        "message": f"Person detected - {len(detections)} in frame",
                        "detections": detections,
                        "timestamp": datetime.utcnow().isoformat(),
                    })
            cv2.imshow("SAR YOLOv5 Detection", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--camera", type=int, default=0)
    p.add_argument("--conf", type=float, default=0.35)
    args = p.parse_args()
    run_detection_loop(camera_index=args.camera, conf_threshold=args.conf)
