# AI Processing - YOLOv5 person detection, camera capture
