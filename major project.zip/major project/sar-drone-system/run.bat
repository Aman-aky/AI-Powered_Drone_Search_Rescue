@echo off
echo Starting AI-Powered Drone SAR System
echo.
echo 1. Backend (FastAPI) - port 8000
start cmd /k "cd /d %~dp0 && pip install -r requirements.txt 2>nul && python -m backend.main"
timeout /t 3 /nobreak >nul
echo 2. AI Streamer - camera + detection
start cmd /k "cd /d %~dp0 && python -m ai_processing.streamer --camera 0"
timeout /t 2 /nobreak >nul
echo 3. Frontend - port 5173
start cmd /k "cd /d %~dp0\frontend && npm install 2>nul && npm run dev"
echo.
echo Open http://localhost:5173 in browser
pause
