"""Export project docs (.md) to PDF files."""

from __future__ import annotations

from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[1]
DOCS_DIR = ROOT / "docs"
OUT_DIR = DOCS_DIR / "pdf"


def wrap_lines(text: str, max_chars: int = 100) -> list[str]:
    out: list[str] = []
    for raw in text.splitlines():
        line = raw.replace("\t", "    ")
        if not line:
            out.append("")
            continue
        while len(line) > max_chars:
            split_at = line.rfind(" ", 0, max_chars)
            if split_at <= 0:
                split_at = max_chars
            out.append(line[:split_at])
            line = line[split_at:].lstrip()
        out.append(line)
    return out


def md_to_pdf(md_path: Path, pdf_path: Path) -> None:
    c = canvas.Canvas(str(pdf_path), pagesize=A4)
    width, height = A4
    left = 15 * mm
    top = height - 15 * mm
    y = top

    c.setTitle(md_path.stem)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(left, y, md_path.stem)
    y -= 10 * mm

    text = md_path.read_text(encoding="utf-8", errors="ignore")
    lines = wrap_lines(text, max_chars=108)

    c.setFont("Helvetica", 10)
    line_height = 5 * mm
    for line in lines:
        if y < 15 * mm:
            c.showPage()
            c.setFont("Helvetica", 10)
            y = top
        c.drawString(left, y, line[:160])
        y -= line_height

    c.save()


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    md_files = sorted(DOCS_DIR.glob("*.md"))
    readme = ROOT / "README.md"
    if readme.exists():
        md_files.append(readme)

    if not md_files:
        print("No markdown docs found.")
        return

    for md in md_files:
        out_name = md.stem + ".pdf"
        out = OUT_DIR / out_name
        md_to_pdf(md, out)
        print(f"Generated: {out}")


if __name__ == "__main__":
    main()
