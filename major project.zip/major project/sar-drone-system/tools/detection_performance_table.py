"""Generate detection performance table for SAR project."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass


@dataclass
class Metrics:
    tp: int
    fp: int
    fn: int
    tn: int
    avg_inference_ms: float
    avg_alert_latency_ms: float
    model: str
    conf_threshold: float

    @property
    def precision(self) -> float:
        d = self.tp + self.fp
        return (self.tp / d) if d else 0.0

    @property
    def recall(self) -> float:
        d = self.tp + self.fn
        return (self.tp / d) if d else 0.0

    @property
    def f1(self) -> float:
        p, r = self.precision, self.recall
        return (2 * p * r / (p + r)) if (p + r) else 0.0

    @property
    def accuracy(self) -> float:
        total = self.tp + self.fp + self.fn + self.tn
        return ((self.tp + self.tn) / total) if total else 0.0

    @property
    def fps(self) -> float:
        return (1000.0 / self.avg_inference_ms) if self.avg_inference_ms > 0 else 0.0


def pct(value: float) -> str:
    return f"{value * 100:.2f}%"


def print_table(m: Metrics) -> None:
    rows = [
        ("Model", m.model, "YOLO model used in project"),
        ("Confidence Threshold", f"{m.conf_threshold:.2f}", "Detection threshold"),
        ("True Positives (TP)", str(m.tp), "Person correctly detected"),
        ("False Positives (FP)", str(m.fp), "Non-person flagged as person"),
        ("False Negatives (FN)", str(m.fn), "Person missed"),
        ("True Negatives (TN)", str(m.tn), "No-person correctly rejected"),
        ("Precision", pct(m.precision), "TP / (TP + FP)"),
        ("Recall", pct(m.recall), "TP / (TP + FN)"),
        ("F1 Score", pct(m.f1), "2PR / (P + R)"),
        ("Accuracy", pct(m.accuracy), "(TP + TN) / Total"),
        ("Avg Inference Time", f"{m.avg_inference_ms:.2f} ms", "Per frame"),
        ("FPS", f"{m.fps:.2f}", "1000 / inference_ms"),
        ("Avg Alert Latency", f"{m.avg_alert_latency_ms:.2f} ms", "Capture to alert"),
    ]

    w1 = max(len(r[0]) for r in rows + [("Metric", "", "")])
    w2 = max(len(r[1]) for r in rows + [("", "Value", "")])
    w3 = max(len(r[2]) for r in rows + [("", "", "Notes")])

    sep = f"+-{'-'*w1}-+-{'-'*w2}-+-{'-'*w3}-+"
    print(sep)
    print(f"| {'Metric'.ljust(w1)} | {'Value'.ljust(w2)} | {'Notes'.ljust(w3)} |")
    print(sep)
    for a, b, c in rows:
        print(f"| {a.ljust(w1)} | {b.ljust(w2)} | {c.ljust(w3)} |")
    print(sep)

    print("\nMarkdown table:\n")
    print("| Metric | Value | Notes |")
    print("|---|---:|---|")
    for a, b, c in rows:
        print(f"| {a} | {b} | {c} |")


def main() -> None:
    parser = argparse.ArgumentParser(description="Detection Performance Table Generator")
    parser.add_argument("--tp", type=int, default=402)
    parser.add_argument("--fp", type=int, default=38)
    parser.add_argument("--fn", type=int, default=60)
    parser.add_argument("--tn", type=int, default=500)
    parser.add_argument("--inference-ms", type=float, default=42.0)
    parser.add_argument("--latency-ms", type=float, default=180.0)
    parser.add_argument("--model", type=str, default="yolov5n")
    parser.add_argument("--conf", type=float, default=0.35)
    parser.add_argument("--json-out", type=str, default="")
    args = parser.parse_args()

    metrics = Metrics(
        tp=args.tp,
        fp=args.fp,
        fn=args.fn,
        tn=args.tn,
        avg_inference_ms=args.inference_ms,
        avg_alert_latency_ms=args.latency_ms,
        model=args.model,
        conf_threshold=args.conf,
    )
    print_table(metrics)

    if args.json_out:
        payload = {
            "model": metrics.model,
            "confidence_threshold": metrics.conf_threshold,
            "tp": metrics.tp,
            "fp": metrics.fp,
            "fn": metrics.fn,
            "tn": metrics.tn,
            "precision": metrics.precision,
            "recall": metrics.recall,
            "f1_score": metrics.f1,
            "accuracy": metrics.accuracy,
            "avg_inference_ms": metrics.avg_inference_ms,
            "fps": metrics.fps,
            "avg_alert_latency_ms": metrics.avg_alert_latency_ms,
        }
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        print(f"\nSaved JSON: {args.json_out}")


if __name__ == "__main__":
    main()
