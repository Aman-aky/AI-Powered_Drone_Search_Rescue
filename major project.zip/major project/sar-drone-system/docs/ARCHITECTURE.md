# AI-Powered Drone Search & Rescue - System Architecture

## High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              GROUND CONTROL STATION (GCS)                                 │
│                                                                                           │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐   │
│  │                         React Dashboard (Browser)                                  │   │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌─────────┐  │   │
│  │  │ Live Video   │ │ Mission Map  │ │ Detection    │ │ Status       │ │ Drone   │  │   │
│  │  │ Feed         │ │ (Leaflet)    │ │ Alerts       │ │ Dashboard    │ │ Control │  │   │
│  │  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘ └─────────┘  │   │
│  │         WebSocket ◄──────────────────────────────────────────────────────────     │   │
│  └─────────────────────────────────────────────────────────────────────────────────┘   │
│                                          ▲                                                │
│                                          │ HTTP / WebSocket                               │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐   │
│  │                    FastAPI Backend (Python)                                        │   │
│  │  • REST API (arm, disarm, takeoff, land, goto, mission)                           │   │
│  │  • WebSocket server (telemetry, alerts, video frames)                             │   │
│  │  • MAVSDK integration for Pixhawk/PX4                                             │   │
│  └─────────────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                           ▲
                              Telemetry / MAVLink (UDP 14540 or Serial 57600)
                                           ▲
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              DRONE (Onboard - Jetson Nano)                               │
│                                                                                           │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────────────────┐  │
│  │ Pixhawk / PX4       │  │ AI Processing       │  │ Ground Link (optional)           │  │
│  │ • Flight control    │  │ • YOLOv5/YOLOv8     │  │ • WiFi / 4G / Telemetry radio   │  │
│  │ • GPS (uBlox Neo)   │  │ • Person detection  │  │ • Stream frames + detections    │  │
│  │ • RC receiver       │  │ • Camera capture    │  │   to backend                    │  │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────────────────┘  │
│           ▲                              ▲                                                │
│           │ MAVLink                      │ USB/CSI                                         │
│  ┌────────┴────────┐           ┌────────┴────────┐                                        │
│  │ Motors, ESCs,   │           │ RGB Camera      │                                        │
│  │ GPS, Telemetry  │           │ (Pi v3 / C920)  │                                        │
│  └─────────────────┘           └─────────────────┘                                        │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

## System Flow

```
1. Operator opens dashboard in browser
2. Dashboard connects to backend via WebSocket
3. Backend connects to drone via MAVLink (UDP or Serial)
4. AI streamer (on Jetson or GCS PC) captures camera, runs YOLOv5 detection
5. Detections + frames POSTed to backend → broadcast to dashboard
6. Telemetry pushed from backend (MAVSDK) → dashboard
7. Operator sends commands (arm, takeoff, goto) via REST API → MAVSDK → drone
```

## Component Responsibilities

| Component | Role |
|-----------|------|
| **React Dashboard** | Live feed, map, alerts, status, control panel; WebSocket client |
| **FastAPI Backend** | REST API, WebSocket server, MAVSDK drone control |
| **AI Streamer** | Camera capture, YOLOv5 inference, POST frames/alerts to backend |
| **Drone Controller** | MAVSDK wrapper for arm, disarm, takeoff, land, goto, mission |
| **Pixhawk/PX4** | Flight controller, GPS navigation, motor control |
