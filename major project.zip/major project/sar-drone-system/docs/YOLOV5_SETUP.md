# YOLOv5 Setup for SAR Drone

Detection uses **YOLOv5** from https://github.com/ultralytics/yolov5.

## Automatic (Recommended)

PyTorch Hub downloads YOLOv5 automatically on first run:

```bash
pip install torch torchvision opencv-python numpy
python -m backend.main
```

When you press Enter or click Detect, the model downloads from the ultralytics/yolov5 repo.

## Manual Clone (Optional)

```bash
cd sar-drone-system
git clone https://github.com/ultralytics/yolov5
cd yolov5
pip install -r requirements.txt
```

Then the backend will use `torch.hub.load("ultralytics/yolov5", "yolov5n")` which can use a cached copy.

## Model Variants

- **yolov5n** – Nano (default, fastest)
- **yolov5s** – Small
- **yolov5m** – Medium (more accurate, slower)

Edit `ai_processing/detector.py` → `load_model("yolov5s")` to change.

## Test Detection

```bash
# Backend (required for /api/detect)
python -m backend.main

# Or run standalone camera detection
python -m ai_processing.detector --camera 0 --conf 0.35
```
