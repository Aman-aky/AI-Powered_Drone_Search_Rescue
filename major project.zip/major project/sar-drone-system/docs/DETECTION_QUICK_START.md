# Person Detection & Capture – Quick Start

## How to detect persons and see results

### 1. Install dependencies
```bash
pip install ultralytics opencv-python requests
```

### 2. Start the backend
```bash
python -m backend.main
```

### 3. Run the AI streamer
```bash
python -m ai_processing.streamer --camera 0 --conf 0.35
```

### 4. Open the dashboard
Open http://localhost:5173 in your browser.

### What you’ll see

- **Live feed**: Video with green boxes around detected persons  
- **Detection badge**: “X person(s) detected” when someone is in frame  
- **Alerts panel**: New entries when a person is detected  
- **Result table**: All detections with time, confidence, and location  

### Tips

- Use `--conf 0.35` (or lower) if detections are missed  
- Ensure good lighting and the person is clearly visible  
- The streamer must run on the machine where the camera is connected  
