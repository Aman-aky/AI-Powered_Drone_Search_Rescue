# AI Model Implementation Details

## Person Detection

- **Model**: YOLOv8n ( Ultralytics ) or YOLOv5n
- **Class**: Person (COCO class 0)
- **Input**: RGB frame from camera
- **Output**: Bounding boxes `[x1, y1, x2, y2]`, confidence score

## Implementation

### Ultralytics (default)

```python
from ultralytics import YOLO
model = YOLO("yolov8n.pt")
results = model.predict(frame, conf=0.5, classes=[0])  # class 0 = person
```

### YOLOv5 (optional)

```python
import torch
model = torch.hub.load("ultralytics/yolov5", "yolov5n", pretrained=True)
results = model(frame)
```

## Thermal + RGB Fusion (Optional)

Per guide, thermal (MLX90640) can be fused with RGB:

1. Read thermal heatmap via I2C
2. Resize to match RGB resolution
3. Concatenate channels or use dual-input CNN
4. Run fused inference for improved low-visibility detection

## Edge Deployment (Jetson Nano)

- Use YOLOv5n or YOLOv8n for best speed
- JetPack 4.6+, PyTorch with CUDA
- Recommended: TensorRT export for faster inference
