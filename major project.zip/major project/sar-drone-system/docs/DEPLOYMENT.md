# Deployment Steps

## Prerequisites

- Python 3.10+
- Node.js 18+
- (Optional) NVIDIA Jetson Nano with JetPack 4.6+
- (Optional) Pixhawk/PX4 drone

## 1. Clone & Setup

```bash
cd sar-drone-system
cp .env.example .env
# Edit .env if needed (DRONE_CONNECTION, CAMERA_INDEX, etc.)
```

## 2. Backend

```bash
pip install -r requirements.txt
python -m backend.main
# Or: uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

Backend runs at `http://localhost:8000`.

## 3. AI Streamer (for live feed + detection)

```bash
pip install -r requirements.txt
python -m ai_processing.streamer --camera 0 --conf 0.5
```

Ensure backend is running. Streamer POSTs frames and alerts to backend.

## 4. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## 5. Production Build

```bash
cd frontend
npm run build
# Serve dist/ with nginx or similar
```

## 6. Jetson Nano (Onboard)

1. Flash JetPack 4.6
2. Install Python deps: `pip install -r requirements.txt`
3. Connect camera (USB or CSI)
4. Run streamer: `python -m ai_processing.streamer --camera 0`
5. Point `BACKEND_URL` to GCS IP if backend runs on ground station

## 7. Drone Connection

- **Simulation**: `DRONE_CONNECTION=udp://:14540` (default)
- **Serial (Linux)**: `DRONE_CONNECTION=serial:///dev/ttyUSB0:57600`
- **Serial (Windows)**: `DRONE_CONNECTION=serial://COM3:57600`

## Ports

| Service | Port |
|---------|------|
| Backend (FastAPI) | 8000 |
| Frontend (Vite dev) | 5173 |
| MAVLink (UDP) | 14540 |
