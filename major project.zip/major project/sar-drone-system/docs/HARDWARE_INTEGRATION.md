# Hardware-Software Integration Guide

## Hardware Components (per Guide)

| Component | Spec | Integration |
|-----------|------|-------------|
| **Frame + Flight Controller** | F450 + Pixhawk (PX4) | MAVSDK connects via Serial `/dev/ttyUSB0:57600` or UDP `udp://:14540` |
| **Motors + ESC + Props** | A2212 1000KV, 30A ESC | Controlled by Pixhawk |
| **GPS & Telemetry** | uBlox Neo-M8N, 433MHz | Connected to Pixhawk; telemetry to GCS |
| **RGB Camera** | Raspberry Pi v3 / Logitech C920 | USB to Jetson Nano (or GCS PC for dev) |
| **Thermal (Optional)** | MLX90640 | I2C to Jetson; fusion in AI module |
| **Onboard Computer** | Jetson Nano | Runs YOLOv5, camera capture, MAVLink client |

## Wiring Overview

```
Pixhawk ◄──► Telemetry Radio (433MHz) ◄──► GCS (laptop/tablet)
    │
    ├── ESCs (4x) → Motors
    ├── GPS (uBlox)
    ├── RC Receiver
    └── Serial ◄──► Jetson Nano (optional onboard control)

Jetson Nano
    ├── USB Camera (C920 / Pi Cam)
    ├── I2C Thermal (MLX90640) [optional]
    └── Power from UBEC (5V 3A from LiPo)
```

## Software ↔ Hardware Mapping

| Hardware | Software Interface |
|----------|--------------------|
| Pixhawk | `mavsdk` (Python), connection `serial:///dev/ttyUSB0:57600` or `udp://:14540` |
| Camera | OpenCV `cv2.VideoCapture(0)` (USB) or CSI |
| GPS | Via MAVSDK telemetry `position()`, `gps_info()` |
| Battery | Via MAVSDK `battery()` |

## Connection Modes

1. **Simulation (SITL)**  
   - Run PX4 SITL, connect backend with `DRONE_CONNECTION=udp://:14540`  
   - No hardware required

2. **Real Drone (Serial)**  
   - Connect Pixhawk USB to GCS or Jetson  
   - Set `DRONE_CONNECTION=serial:///dev/ttyUSB0:57600` (Linux) or `COM3:57600` (Windows)

3. **Real Drone (Telemetry)**  
   - Use 433MHz telemetry modem; GCS runs `mavproxy` or compatible bridge  
   - Backend connects to local MAVLink port (e.g. `udp://127.0.0.1:14550`)
