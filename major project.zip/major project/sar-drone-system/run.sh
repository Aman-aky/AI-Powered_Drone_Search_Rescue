#!/bin/bash
cd "$(dirname "$0")"
echo "Starting AI-Powered Drone SAR System"
echo "1. Backend (port 8000)..."
python -m backend.main &
sleep 3
echo "2. AI Streamer..."
python -m ai_processing.streamer --camera 0 &
sleep 2
echo "3. Frontend (port 5173)..."
cd frontend && npm install && npm run dev &
echo "Open http://localhost:5173 in browser"
