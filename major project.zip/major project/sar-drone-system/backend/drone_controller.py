"""Drone control via MAVSDK (Pixhawk/PX4)."""
import asyncio
import logging
from typing import Optional
from mavsdk import System
from backend.models import DroneState, Telemetry, MissionPoint

logger = logging.getLogger(__name__)


class DroneController:
    def __init__(self, connection: str = "udp://:14540"):
        self.drone = System()
        self.connection = connection
        self._state = DroneState.IDLE
        self._connected = False
        self._telemetry_task: Optional[asyncio.Task] = None

    async def connect(self) -> bool:
        """Connect to the drone."""
        try:
            await self.drone.connect(system_address=self.connection)
            async for state in self.drone.core.connection_state():
                if state.is_connected:
                    self._connected = True
                    logger.info("Connected to drone")
                    return True
                if state.is_connection_lost:
                    break
        except Exception as e:
            logger.error(f"Connection failed: {e}")
        return False

    def is_connected(self) -> bool:
        return self._connected

    async def get_telemetry(self) -> Optional[Telemetry]:
        """Fetch current telemetry from drone."""
        if not self._connected:
            return None
        try:
            pos = await self.drone.telemetry.position()
            bat = await self.drone.telemetry.battery()
            gps = await self.drone.telemetry.gps_info()
            att = await self.drone.telemetry.attitude_euler()
            groundspeed = await self.drone.telemetry.ground_speed_ned()
            fm = await self.drone.telemetry.flight_mode()

            speed = (groundspeed.north_m_s ** 2 + groundspeed.east_m_s ** 2) ** 0.5
            return Telemetry(
                latitude=pos.latitude_deg,
                longitude=pos.longitude_deg,
                altitude=pos.absolute_altitude_m,
                heading=att.heading_deg,
                speed=speed,
                battery_percent=bat.remaining_percent * 100,
                flight_mode=str(fm),
            )
        except Exception as e:
            logger.debug(f"Telemetry error: {e}")
            return None

    async def arm(self) -> bool:
        """Arm the drone."""
        if not self._connected:
            return False
        try:
            await self.drone.action.arm()
            self._state = DroneState.ARMED
            return True
        except Exception as e:
            logger.error(f"Arm failed: {e}")
            return False

    async def disarm(self) -> bool:
        """Disarm the drone."""
        if not self._connected:
            return False
        try:
            await self.drone.action.disarm()
            self._state = DroneState.IDLE
            return True
        except Exception as e:
            logger.error(f"Disarm failed: {e}")
            return False

    async def takeoff(self, altitude_m: float = 5.0) -> bool:
        """Take off to specified altitude."""
        if not self._connected:
            return False
        try:
            await self.drone.action.arm()
            await self.drone.action.takeoff()
            self._state = DroneState.TAKEOFF
            await asyncio.sleep(1)
            self._state = DroneState.FLYING
            return True
        except Exception as e:
            logger.error(f"Takeoff failed: {e}")
            return False

    async def land(self) -> bool:
        """Land the drone."""
        if not self._connected:
            return False
        try:
            await self.drone.action.land()
            self._state = DroneState.LANDING
            return True
        except Exception as e:
            logger.error(f"Land failed: {e}")
            return False

    async def goto_location(self, lat: float, lon: float, alt: float) -> bool:
        """Fly to a specific GPS location."""
        if not self._connected:
            return False
        try:
            await self.drone.action.goto_location(lat, lon, alt, 0)
            return True
        except Exception as e:
            logger.error(f"Goto failed: {e}")
            return False

    async def upload_mission(self, waypoints: list[MissionPoint]) -> bool:
        """Upload a mission with waypoints."""
        if not self._connected or not waypoints:
            return False
        try:
            mission_items = []
            for i, wp in enumerate(waypoints):
                mission_items.append(
                    (
                        wp.latitude,
                        wp.longitude,
                        wp.altitude,
                        10,  # acceptance radius
                        0,  # loiter time
                        float("nan"),  # gimbal yaw
                        float("nan"),  # gimbal pitch
                        float("nan"),  # camera action
                        float("nan"),  # camera zoom
                        0,  # speed
                        0,  # camera photo distance
                        float("nan"),  # camera photo time
                    )
                )
            await self.drone.mission.upload_mission(mission_items)
            return True
        except Exception as e:
            logger.error(f"Mission upload failed: {e}")
            return False

    async def start_mission(self) -> bool:
        """Start the uploaded mission."""
        if not self._connected:
            return False
        try:
            await self.drone.mission.start_mission()
            self._state = DroneState.FLYING
            return True
        except Exception as e:
            logger.error(f"Start mission failed: {e}")
            return False

    def get_state(self) -> DroneState:
        return self._state
