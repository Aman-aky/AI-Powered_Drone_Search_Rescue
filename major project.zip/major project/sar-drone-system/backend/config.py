"""Configuration for backend services."""
import os
from dotenv import load_dotenv

load_dotenv()

DRONE_CONNECTION = os.getenv("DRONE_CONNECTION", "udpin://0.0.0.0:14540")
BACKEND_HOST = os.getenv("BACKEND_HOST", "0.0.0.0")
BACKEND_PORT = int(os.getenv("BACKEND_PORT", "8000"))
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173")
