"""Data models for telemetry, alerts, and commands."""
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum


class DroneState(str, Enum):
    IDLE = "idle"
    ARMED = "armed"
    TAKEOFF = "takeoff"
    FLYING = "flying"
    LANDING = "landing"
    LANDED = "landed"
    ERROR = "error"


class Telemetry(BaseModel):
    latitude: float
    longitude: float
    altitude: float
    heading: float
    speed: float
    battery_percent: float
    flight_mode: str
    timestamp: datetime = None

    def __init__(self, **data):
        if "timestamp" not in data:
            data["timestamp"] = datetime.utcnow()
        super().__init__(**data)


class Detection(BaseModel):
    label: str
    confidence: float
    bbox: list[float]  # [x1, y1, x2, y2]
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    timestamp: datetime = None

    def __init__(self, **data):
        if "timestamp" not in data:
            data["timestamp"] = datetime.utcnow()
        super().__init__(**data)


class Alert(BaseModel):
    id: str
    type: str = "victim_detected"
    severity: str = "high"
    message: str
    detections: list[Detection] = []
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    timestamp: datetime = None

    def __init__(self, **data):
        if "timestamp" not in data:
            data["timestamp"] = datetime.utcnow()
        super().__init__(**data)


class MissionPoint(BaseModel):
    latitude: float
    longitude: float
    altitude: float
    seq: int = 0

