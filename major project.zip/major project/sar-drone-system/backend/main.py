"""FastAPI backend - WebSocket streaming, REST API, drone control."""
import asyncio
import base64
import json
import logging
from datetime import datetime
from typing import Set

import cv2
import numpy as np

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from contextlib import asynccontextmanager

from backend.config import DRONE_CONNECTION, FRONTEND_URL
from backend.drone_controller import DroneController
from backend.models import DroneState, MissionPoint, Telemetry

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global state
drone: DroneController | None = None
connected_clients: Set[WebSocket] = set()
telemetry_queue: asyncio.Queue | None = None
alert_queue: asyncio.Queue | None = None
video_frame_queue: asyncio.Queue | None = None


async def broadcast(data: dict, exclude: WebSocket | None = None):
    """Broadcast JSON to all connected WebSocket clients."""
    msg = json.dumps(data, default=str)
    disconnected = []
    for ws in connected_clients:
        if ws == exclude:
            continue
        try:
            await ws.send_text(msg)
        except Exception:
            disconnected.append(ws)
    for ws in disconnected:
        connected_clients.discard(ws)


async def telemetry_pusher():
    """Periodically fetch telemetry and broadcast to clients."""
    global drone, telemetry_queue
    while True:
        try:
            if drone and drone.is_connected() and connected_clients:
                t = await drone.get_telemetry()
                if t:
                    payload = {
                        "type": "telemetry",
                        "data": t.model_dump(mode="json"),
                    }
                    await broadcast(payload)
            await asyncio.sleep(0.5)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.debug(f"Telemetry error: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    global drone, telemetry_queue, alert_queue, video_frame_queue
    telemetry_queue = asyncio.Queue()
    alert_queue = asyncio.Queue()
    video_frame_queue = asyncio.Queue()

    drone = DroneController(connection=DRONE_CONNECTION)
    try:
        await drone.connect()
    except Exception as e:
        logger.warning(f"Drone not connected (simulation mode): {e}")

    pusher = asyncio.create_task(telemetry_pusher())
    yield
    pusher.cancel()


app = FastAPI(title="SAR Drone API", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- REST API ---

class WaypointInput(BaseModel):
    latitude: float
    longitude: float
    altitude: float = 10.0


class MissionInput(BaseModel):
    waypoints: list[WaypointInput]


@app.get("/health")
async def health():
    return {"status": "ok", "drone_connected": drone.is_connected() if drone else False}


@app.get("/api/telemetry")
async def get_telemetry():
    if not drone or not drone.is_connected():
        return {"status": "not_connected", "telemetry": None}
    t = await drone.get_telemetry()
    return {"status": "ok", "telemetry": t.model_dump(mode="json") if t else None}


@app.post("/api/arm")
async def api_arm():
    if not drone or not drone.is_connected():
        return JSONResponse({"error": "Drone not connected"}, status_code=503)
    ok = await drone.arm()
    return {"success": ok}


@app.post("/api/disarm")
async def api_disarm():
    if not drone or not drone.is_connected():
        return JSONResponse({"error": "Drone not connected"}, status_code=503)
    ok = await drone.disarm()
    return {"success": ok}


@app.post("/api/takeoff")
async def api_takeoff(altitude: float = 5.0):
    if not drone or not drone.is_connected():
        return JSONResponse({"error": "Drone not connected"}, status_code=503)
    ok = await drone.takeoff(altitude_m=altitude)
    return {"success": ok}


@app.post("/api/land")
async def api_land():
    if not drone or not drone.is_connected():
        return JSONResponse({"error": "Drone not connected"}, status_code=503)
    ok = await drone.land()
    return {"success": ok}


@app.post("/api/goto")
async def api_goto(wp: WaypointInput):
    if not drone or not drone.is_connected():
        return JSONResponse({"error": "Drone not connected"}, status_code=503)
    ok = await drone.goto_location(wp.latitude, wp.longitude, wp.altitude)
    return {"success": ok}


@app.post("/api/frame")
async def api_frame(request: Request):
    """Receive video frame + detections from AI streamer, broadcast to WebSocket clients."""
    payload = await request.json()
    await broadcast({"type": "frame", "data": payload})
    return {"success": True}


@app.post("/api/alert")
async def api_alert(request: Request):
    """Receive detection alerts from AI processor and broadcast to WebSocket clients."""
    alert = await request.json()
    await broadcast({"type": "alert", "data": alert})
    return {"success": True}


def _run_detection(img_b64: str, conf: float):
    """Blocking detection - run in thread."""
    from ai_processing.detector import load_model, run_inference, draw_detections
    raw = base64.b64decode(img_b64)
    arr = np.frombuffer(raw, dtype=np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        raise ValueError("Invalid image")
    load_model()
    results = run_inference(frame, conf=conf)
    frame_out, detections = draw_detections(frame, results, conf)
    _, buf = cv2.imencode(".jpg", frame_out)
    return {"detections": detections, "frame": base64.b64encode(buf).decode(), "count": len(detections)}


@app.post("/api/detect")
async def api_detect(request: Request):
    """Run YOLO detection on image from browser webcam. Accepts base64 JPEG."""
    try:
        body = await request.json()
        img_b64 = body.get("image")
        conf = float(body.get("conf", 0.35))
        if not img_b64:
            return JSONResponse({"error": "No image"}, status_code=400)
        result = await asyncio.to_thread(_run_detection, img_b64, conf)
        return result
    except Exception as e:
        logger.exception("Detect error")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/detection")
async def api_detection(request: Request):
    """Receive detection overlay from AI processor."""
    detection = await request.json()
    await broadcast({"type": "detection", "data": detection})
    return {"success": True}


@app.post("/api/mission")
async def api_mission(m: MissionInput):
    if not drone or not drone.is_connected():
        return JSONResponse({"error": "Drone not connected"}, status_code=503)
    points = [MissionPoint(latitude=w.latitude, longitude=w.longitude, altitude=w.altitude) for w in m.waypoints]
    ok = await drone.upload_mission(points)
    if ok:
        ok2 = await drone.start_mission()
        return {"success": ok2}
    return {"success": False}


# --- WebSocket ---

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    connected_clients.add(ws)
    logger.info(f"Client connected. Total: {len(connected_clients)}")

    try:
        while True:
            data = await ws.receive_text()
            msg = json.loads(data)
            typ = msg.get("type")
            if typ == "ping":
                await ws.send_text(json.dumps({"type": "pong", "ts": datetime.utcnow().isoformat()}))
    except WebSocketDisconnect:
        pass
    except json.JSONDecodeError:
        pass
    finally:
        connected_clients.discard(ws)
        logger.info(f"Client disconnected. Total: {len(connected_clients)}")


def emit_alert(alert: dict):
    """Called by AI processor to push detection alerts."""
    asyncio.create_task(_emit_alert(alert))


async def _emit_alert(alert: dict):
    payload = {"type": "alert", "data": alert}
    await broadcast(payload)


def emit_telemetry(telemetry: dict):
    """Emit telemetry from external source (e.g. AI processor with GPS)."""
    asyncio.create_task(_emit_telemetry(telemetry))


async def _emit_telemetry(t: dict):
    payload = {"type": "telemetry", "data": t}
    await broadcast(payload)


def emit_detection(detection: dict):
    """Emit detection overlay (no full alert)."""
    asyncio.create_task(_emit_detection(detection))


async def _emit_detection(d: dict):
    payload = {"type": "detection", "data": d}
    await broadcast(payload)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
