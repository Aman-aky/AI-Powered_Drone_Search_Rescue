# AI-Powered Drone Search and Rescue System

A production-ready, AI-integrated drone system for search and rescue operations with real-time person detection (YOLOv5 from [ultralytics/yolov5](https://github.com/ultralytics/yolov5)), autonomous navigation, and professional ground control dashboard.

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        GROUND CONTROL STATION                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ Live Video   │  │ Map & GPS    │  │ Detection    │  │ Drone        │    │
│  │ Feed         │  │ Tracking     │  │ Alerts       │  │ Control      │    │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘    │
│                              React Dashboard (WebSocket)                     │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                   Telemetry / 433MHz
                                        │
┌─────────────────────────────────────────────────────────────────────────────┐
│                        DRONE (Onboard - Jetson Nano)                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ Pixhawk/PX4  │  │ YOLOv5 AI    │  │ RGB Camera   │  │ GPS/IMU      │    │
│  │ Flight Ctrl  │  │ Person Det.  │  │ (Pi/Logitech)│  │ uBlox Neo    │    │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Install dependencies
cd sar-drone-system
pip install -r requirements.txt
cd frontend && npm install

# 2. Start backend & AI processor
python -m backend.main &
python -m ai_processing.detector &

# 3. Start frontend
cd frontend && npm run dev

# 4. Open http://localhost:5173
```

## Deployment

See [DEPLOYMENT.md](docs/DEPLOYMENT.md) for full deployment instructions.
