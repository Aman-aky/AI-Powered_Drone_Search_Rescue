import { useState, useEffect, useCallback, useRef } from 'react'
import { LiveFeed } from './components/LiveFeed'
import { MapView } from './components/MapView'
import { AlertsPanel } from './components/AlertsPanel'
import { StatusDashboard } from './components/StatusDashboard'
import { ControlPanel } from './components/ControlPanel'
import { VoiceDetection } from './components/VoiceDetection'
import { ResultsTable } from './components/ResultsTable'
import { Header } from './components/Header'
import { useWebSocket } from './hooks/useWebSocket'
import './App.css'

const WS_URL = import.meta.env.VITE_WS_URL || (() => {
  const { protocol, host } = window.location
  const wsProtocol = protocol === 'https:' ? 'wss:' : 'ws:'
  return `${wsProtocol}//${host}/ws`
})()

export default function App() {
  const [telemetry, setTelemetry] = useState(null)
  const [alerts, setAlerts] = useState([])
  const [frame, setFrame] = useState(null)
  const [detections, setDetections] = useState([])
  const [droneConnected, setDroneConnected] = useState(false)
  const [wsConnected, setWsConnected] = useState(false)
  const [demoMode, setDemoMode] = useState(false)
  const [toast, setToast] = useState(null)
  const telemetryRef = useRef(null)
  useEffect(() => { telemetryRef.current = telemetry }, [telemetry])

  const showToast = useCallback((msg, type = 'info') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }, [])

  const handleVoiceAlert = useCallback((alert) => {
    const full = {
      ...alert,
      id: `voice-${Date.now()}`,
      timestamp: new Date().toISOString(),
      receivedAt: Date.now(),
      message: `Voice detected: "${alert.keyword}"`,
    }
    setAlerts((prev) => [full, ...prev].slice(0, 50))
    showToast(`Voice alert: ${alert.keyword}`, 'warning')
    fetch('/api/alert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(full),
    }).catch(() => {})
  }, [showToast])

  const handleMessage = useCallback((msg) => {
    try {
      const data = typeof msg === 'string' ? JSON.parse(msg) : msg
      switch (data.type) {
        case 'telemetry':
          setTelemetry(data.data)
          setDroneConnected(true)
          break
        case 'alert': {
          const alert = { ...data.data, receivedAt: Date.now() }
          if (alert.latitude == null || alert.longitude == null) {
            const t = telemetryRef.current
            if (t?.latitude != null && t?.longitude != null) {
              alert.latitude = t.latitude
              alert.longitude = t.longitude
              alert.location = `${t.latitude.toFixed(5)}, ${t.longitude.toFixed(5)}`
            }
          }
          setAlerts((prev) => [alert, ...prev].slice(0, 50))
          showToast('Person detected!', 'warning')
          break
        }
          break
        case 'frame':
          if (data.data?.frame) setFrame(data.data.frame)
          if (data.data?.detections) setDetections(data.data.detections || [])
          break
        case 'detection':
          if (data.data) setDetections(data.data.detections || [data.data])
          break
        default:
          break
      }
    } catch (e) {
      console.debug('WS parse:', e)
    }
  }, [showToast])

  const { connect, disconnect, isConnected } = useWebSocket(WS_URL, handleMessage)

  useEffect(() => {
    connect()
    return () => disconnect()
  }, [connect, disconnect])

  useEffect(() => {
    setWsConnected(isConnected)
  }, [isConnected])

  useEffect(() => {
    const check = async () => {
      try {
        const r = await fetch('/health')
        const j = await r.json()
        setDroneConnected(j.drone_connected || false)
      } catch {
        setDroneConnected(false)
      }
    }
    check()
    const id = setInterval(check, 5000)
    return () => clearInterval(id)
  }, [])

  // Demo mode: inject mock telemetry
  useEffect(() => {
    if (!demoMode) return
    const mock = () => ({
      latitude: 28.6139 + (Math.random() - 0.5) * 0.01,
      longitude: 77.209 + (Math.random() - 0.5) * 0.01,
      altitude: 15 + Math.random() * 5,
      heading: Math.random() * 360,
      speed: 2 + Math.random() * 3,
      battery_percent: 65 - Math.random() * 5,
      flight_mode: 'HOLD',
      timestamp: new Date().toISOString(),
    })
    setTelemetry(mock())
    setDroneConnected(true)
    const id = setInterval(() => setTelemetry(mock()), 2000)
    return () => clearInterval(id)
  }, [demoMode])

  const displayTelemetry = demoMode ? telemetry : telemetry

  return (
    <div className="app">
      <Header
        wsConnected={wsConnected}
        droneConnected={droneConnected}
        demoMode={demoMode}
        onToggleDemo={() => setDemoMode((d) => !d)}
      />
      {toast && (
        <div className={`toast toast-${toast.type}`}>
          {toast.msg}
        </div>
      )}
      <main className="main">
        <div className="grid-top">
          <section className="card live-feed-card">
            <h2>Live Drone Feed & YOLO Detection</h2>
            <LiveFeed
              frame={frame}
              detections={detections}
              telemetry={displayTelemetry}
              streamerActive={!!frame}
              onDetect={(dets, result) => {
                const hasPerson = dets && dets.length > 0
                const alert = {
                  id: `detect-${Date.now()}`,
                  type: hasPerson ? 'victim_detected' : 'scan_complete',
                  severity: hasPerson ? 'high' : 'info',
                  message: hasPerson
                    ? `RESCUE ALERT: ${dets.length} person(s) detected - rescue required`
                    : 'Scan complete - no person in frame',
                  detections: dets || [],
                  timestamp: new Date().toISOString(),
                  receivedAt: Date.now(),
                }
                const t = telemetryRef.current
                if (t?.latitude != null && t?.longitude != null) {
                  alert.latitude = t.latitude
                  alert.longitude = t.longitude
                  alert.location = `${t.latitude.toFixed(5)}, ${t.longitude.toFixed(5)}`
                }
                setAlerts((prev) => [alert, ...prev].slice(0, 50))
                showToast(hasPerson ? 'RESCUE ALERT - Person detected!' : 'Scan captured', hasPerson ? 'warning' : 'info')
                fetch('/api/alert', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(alert),
                }).catch(() => {})
              }}
            />
          </section>
          <section className="card map-card">
            <h2>Mission Map</h2>
            <MapView telemetry={displayTelemetry} alerts={alerts} />
          </section>
        </div>
        <div className="grid-bottom">
          <section className="card alerts-card">
            <h2>Detection Alerts</h2>
            <AlertsPanel alerts={alerts} onClear={() => setAlerts([])} />
          </section>
          <section className="card status-card">
            <h2>Status & Battery Health</h2>
            <StatusDashboard telemetry={displayTelemetry} droneConnected={droneConnected || demoMode} />
          </section>
          <section className="card control-card">
            <h2>Drone Control</h2>
            <ControlPanel
              droneConnected={droneConnected || demoMode}
              demoMode={demoMode}
              onFeedback={showToast}
            />
          </section>
        </div>
        <div className="grid-extra">
          <section className="card voice-card">
            <h2>Voice Detection</h2>
            <VoiceDetection onVoiceAlert={handleVoiceAlert} />
          </section>
          <section className="card results-card">
            <h2>Result</h2>
            <ResultsTable alerts={alerts} telemetry={displayTelemetry} />
          </section>
        </div>
      </main>
    </div>
  )
}
