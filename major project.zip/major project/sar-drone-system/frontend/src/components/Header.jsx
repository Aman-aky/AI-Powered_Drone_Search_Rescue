import './Header.css'

export function Header({ wsConnected, droneConnected, demoMode, onToggleDemo }) {
  return (
    <header className="header">
      <div className="header-left">
        <div className="logo">
          <svg width="32" height="32" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="32" cy="32" r="28" fill="currentColor" opacity="0.2"/>
            <path d="M32 12 L32 28 L20 38 L32 52 L44 38 Z" fill="currentColor" stroke="var(--accent)" strokeWidth="2"/>
            <circle cx="32" cy="24" r="4" fill="var(--accent)"/>
          </svg>
          <span>SAR Drone</span>
        </div>
        <span className="product-tag">Search & Rescue Control</span>
      </div>
      <div className="header-right">
        <StatusPill label="WebSocket" active={wsConnected} />
        <StatusPill label="Drone" active={droneConnected || demoMode} />
        {onToggleDemo && (
          <button
            className={`demo-btn ${demoMode ? 'active' : ''}`}
            onClick={onToggleDemo}
            title="Toggle demo mode (mock telemetry)"
          >
            {demoMode ? 'Demo On' : 'Demo'}
          </button>
        )}
      </div>
    </header>
  )
}

function StatusPill({ label, active }) {
  return (
    <span className={`status-pill ${active ? 'active' : ''}`}>
      <span className="dot" />
      {label}
    </span>
  )
}
