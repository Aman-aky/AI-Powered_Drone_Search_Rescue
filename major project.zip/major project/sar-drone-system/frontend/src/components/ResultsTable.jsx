import { useMemo } from 'react'
import './ResultsTable.css'

function formatTime(ts) {
  if (!ts) return '—'
  try {
    const d = new Date(ts)
    return d.toLocaleTimeString()
  } catch {
    return '—'
  }
}

export function ResultsTable({ alerts, telemetry }) {
  const rows = useMemo(() => {
    const out = []
    alerts.forEach((a, i) => {
      const type = a.type === 'voice_detected' ? 'Voice' : 'Person (YOLO)'
      const confidence = a.type === 'voice_detected'
        ? a.keyword || '—'
        : a.detections?.[0]?.confidence != null
          ? `${(a.detections[0].confidence * 100).toFixed(1)}%`
          : '—'
      const lat = a.latitude ?? telemetry?.latitude ?? '—'
      const lon = a.longitude ?? telemetry?.longitude ?? '—'
      const loc = typeof lat === 'number' && typeof lon === 'number'
        ? `${lat.toFixed(4)}, ${lon.toFixed(4)}`
        : '—'
      out.push({
        id: a.id || `row-${i}`,
        time: formatTime(a.timestamp || a.receivedAt),
        type,
        confidence,
        location: loc,
        message: a.message || a.transcript || (a.type === 'voice_detected' ? `Voice: ${a.keyword}` : 'Person detected'),
        severity: a.severity || 'high',
      })
    })
    return out
  }, [alerts, telemetry])

  return (
    <div className="results-table-wrapper">
      <div className="results-table-header">
        <span>Result</span>
        <span className="results-count">{rows.length} record(s)</span>
      </div>
      <div className="results-table-scroll">
        <table className="results-table">
          <thead>
            <tr>
              <th>Time</th>
              <th>Type</th>
              <th>Confidence/Keyword</th>
              <th>Location</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={5} className="results-empty">No results yet</td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.id} className={`severity-${r.severity}`}>
                  <td className="font-mono">{r.time}</td>
                  <td>
                    <span className={`type-badge ${r.type === 'Voice' ? 'voice' : 'yolo'}`}>
                      {r.type}
                    </span>
                  </td>
                  <td className="font-mono">{r.confidence}</td>
                  <td className="font-mono">{r.location}</td>
                  <td>{r.message}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
