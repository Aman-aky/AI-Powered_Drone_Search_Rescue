import './AlertsPanel.css'

export function AlertsPanel({ alerts, onClear }) {
  return (
    <div className="alerts-panel">
      <div className="alerts-header">
        <span className="count">{alerts.length} alert{alerts.length !== 1 ? 's' : ''}</span>
        {alerts.length > 0 && (
          <button className="clear-btn" onClick={onClear}>
            Clear
          </button>
        )}
      </div>
      <div className="alerts-list">
        {alerts.length === 0 ? (
          <div className="alerts-empty">
            <span>No detection alerts</span>
          </div>
        ) : (
          alerts.slice(0, 10).map((a, i) => (
            <div key={a.id || i} className="alert-item">
              <span className={`severity severity-${a.severity || 'high'}`} />
              <div className="alert-content">
                <p className="alert-message">{a.message || 'Person detected'}</p>
                {a.location && (
                  <p className="alert-location">📍 {a.location}</p>
                )}
                <span className="alert-meta">
                  {a.detections?.length || 0} detection(s) · {formatTime(a.timestamp || a.receivedAt)}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

function formatTime(ts) {
  if (!ts) return ''
  try {
    const d = new Date(ts)
    return d.toLocaleTimeString()
  } catch {
    return ''
  }
}
