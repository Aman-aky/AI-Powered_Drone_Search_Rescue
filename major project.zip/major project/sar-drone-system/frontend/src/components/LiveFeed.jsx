import { useEffect, useRef, useState, useCallback } from 'react'
import './LiveFeed.css'

export function LiveFeed({ frame, detections, telemetry, streamerActive, onDetect }) {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const streamRef = useRef(null)
  const [webcamActive, setWebcamActive] = useState(false)
  const [detecting, setDetecting] = useState(false)
  const [localDetections, setLocalDetections] = useState(null)
  const [localFrame, setLocalFrame] = useState(null)
  const [fps, setFps] = useState(0)
  const frameCountRef = useRef(0)
  const lastFpsTime = useRef(Date.now())

  const displayFrame = frame || localFrame
  const displayDetections = localDetections ?? detections

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } })
      .then((stream) => {
        streamRef.current = stream
        if (videoRef.current) videoRef.current.srcObject = stream
        setWebcamActive(true)
      })
      .catch(() => setWebcamActive(false))
    return () => {
      streamRef.current?.getTracks().forEach((t) => t.stop())
    }
  }, [])

  const runDetection = useCallback(async () => {
    const video = videoRef.current
    if (!video || !video.videoWidth) return
    setDetecting(true)
    try {
      const canvas = document.createElement('canvas')
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      const ctx = canvas.getContext('2d')
      ctx.drawImage(video, 0, 0)
      const blob = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', 0.9))
      const reader = new FileReader()
      reader.readAsDataURL(blob)
      const dataUrl = await new Promise((res) => {
        reader.onloadend = () => res(reader.result)
      })
      const base64 = dataUrl.split(',')[1]
      const r = await fetch('/api/detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64, conf: 0.35 }),
      })
      const j = await r.json()
      if (j.error) throw new Error(j.error)
      const dets = j.detections || []
      setLocalDetections(dets)
      if (j.frame) setLocalFrame(j.frame)
      onDetect?.(dets, j)
    } catch (e) {
      console.error(e)
    } finally {
      setDetecting(false)
    }
  }, [onDetect])

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Enter' && webcamActive && !detecting) {
        if (!e.target.matches('input, textarea')) {
          e.preventDefault()
          runDetection()
        }
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [webcamActive, detecting, runDetection])

  useEffect(() => {
    if (!displayFrame || !canvasRef.current) return
    const img = new Image()
    img.onload = () => {
      const canvas = canvasRef.current
      const ctx = canvas.getContext('2d')
      canvas.width = img.width
      canvas.height = img.height
      ctx.drawImage(img, 0, 0)
    }
    img.src = `data:image/jpeg;base64,${displayFrame}`
  }, [displayFrame])

  useEffect(() => {
    if (!displayFrame) return
    frameCountRef.current += 1
    const now = Date.now()
    const elapsed = (now - lastFpsTime.current) / 1000
    if (elapsed >= 1) {
      setFps(Math.round(frameCountRef.current / elapsed))
      frameCountRef.current = 0
      lastFpsTime.current = now
    }
  }, [displayFrame])

  const hasLocation = telemetry?.latitude != null && telemetry?.longitude != null
  const locationStr = hasLocation
    ? `${telemetry.latitude.toFixed(5)}°N, ${telemetry.longitude.toFixed(5)}°E`
    : 'Awaiting GPS (enable Demo for test location)'

  const showPlaceholder = !webcamActive && !displayFrame

  return (
    <div className="feed-wrapper">
      <div className="feed-container">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`feed-video ${displayFrame ? 'hidden' : ''}`}
        />
        <canvas ref={canvasRef} className={`feed-canvas ${displayFrame ? 'visible' : 'hidden'}`} />
        {showPlaceholder && (
          <div className="feed-placeholder">
            <div className="placeholder-icon">📷</div>
            <p>Camera & YOLO Detection</p>
            <span>Allow camera access to see live feed. Press Enter or click Detect to find persons.</span>
          </div>
        )}
        {webcamActive && !displayFrame && (
          <div className="detect-hint">
            <span>Live camera</span>
            <span>Press <kbd>Enter</kbd> or click below to detect</span>
          </div>
        )}
        {displayFrame && (
          <>
            <div className="feed-overlay">
              <span className="yolo-badge">YOLO Detection</span>
              {streamerActive && fps > 0 && <span className="fps-badge">{fps} fps</span>}
              {displayDetections?.length > 0 && (
                <span className="legend-badge">
                  <span className="legend-green">● Green</span>=OK &nbsp;
                  <span className="legend-red">● Red</span>=Danger
                </span>
              )}
            </div>
            {displayDetections?.length > 0 && (
              <>
                <div className="person-detected-overlay">
                  <div className="person-detected-title">PERSON DETECTED</div>
                  <div className="person-detected-count">{displayDetections.length} person(s) in frame</div>
                  <div className="person-detected-location">
                    <span className="location-label">Location:</span>
                    <span className="location-value">{locationStr}</span>
                  </div>
                  {hasLocation && (
                    <a
                      className="person-detected-map-link"
                      href={`https://www.google.com/maps?q=${telemetry.latitude},${telemetry.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      View on Map →
                    </a>
                  )}
                </div>
                <div className="detection-badge">
                  🔴 {displayDetections.length} person(s) detected
                </div>
              </>
            )}
          </>
        )}
        {webcamActive && (
          <button
            className="detect-btn"
            onClick={runDetection}
            disabled={detecting}
          >
            {detecting ? 'Detecting...' : 'Detect (or press Enter)'}
          </button>
        )}
      </div>
    </div>
  )
}
