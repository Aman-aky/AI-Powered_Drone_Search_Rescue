import { useState } from 'react'
import './ControlPanel.css'

const API = import.meta.env.VITE_API_BASE || ''

export function ControlPanel({ droneConnected, demoMode, onFeedback }) {
  const [loading, setLoading] = useState(null)
  const [altitude, setAltitude] = useState(5)
  const [goto, setGoto] = useState({ lat: '', lon: '', alt: 10 })

  const call = async (action, body = null, query = '') => {
    if (!droneConnected) return
    setLoading(action)
    if (demoMode) {
      await new Promise((r) => setTimeout(r, 500))
      onFeedback?.(`${action} (demo)`, 'info')
      setLoading(null)
      return
    }
    try {
      const url = `${API}/api/${action}${query ? '?' + query : ''}`
      const opts = body
        ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
        : { method: 'POST' }
      const r = await fetch(url, opts)
      const j = await r.json()
      if (!j.success) throw new Error(j.error || 'Failed')
      onFeedback?.(`${action} successful`, 'success')
    } catch (e) {
      onFeedback?.(e.message || 'Failed', 'warning')
    } finally {
      setLoading(null)
    }
  }

  const handleGoto = () => {
    const lat = parseFloat(goto.lat)
    const lon = parseFloat(goto.lon)
    if (isNaN(lat) || isNaN(lon)) return
    call('goto', { latitude: lat, longitude: lon, altitude: goto.alt })
  }

  return (
    <div className="control-panel">
      <div className="control-buttons">
        <button
          className="ctrl-btn arm"
          onClick={() => call('arm')}
          disabled={!droneConnected || loading}
          title="Arm motors"
        >
          {loading === 'arm' ? '...' : 'Arm'}
        </button>
        <button
          className="ctrl-btn disarm"
          onClick={() => call('disarm')}
          disabled={!droneConnected || loading}
          title="Disarm motors"
        >
          {loading === 'disarm' ? '...' : 'Disarm'}
        </button>
        <button
          className="ctrl-btn takeoff"
          onClick={() => call('takeoff', undefined, `altitude=${altitude}`)}
          disabled={!droneConnected || loading}
          title="Takeoff"
        >
          {loading === 'takeoff' ? '...' : 'Takeoff'}
        </button>
        <button
          className="ctrl-btn land"
          onClick={() => call('land')}
          disabled={!droneConnected || loading}
          title="Land"
        >
          {loading === 'land' ? '...' : 'Land'}
        </button>
      </div>
      <div className="goto-section">
        <h3>Go to location</h3>
        <div className="goto-inputs">
          <input
            type="number"
            placeholder="Lat"
            step="any"
            value={goto.lat}
            onChange={(e) => setGoto((g) => ({ ...g, lat: e.target.value }))}
          />
          <input
            type="number"
            placeholder="Lon"
            step="any"
            value={goto.lon}
            onChange={(e) => setGoto((g) => ({ ...g, lon: e.target.value }))}
          />
          <input
            type="number"
            placeholder="Alt (m)"
            min="1"
            value={goto.alt}
            onChange={(e) => setGoto((g) => ({ ...g, alt: parseFloat(e.target.value) || 10 }))}
          />
          <button
            className="goto-btn"
            onClick={handleGoto}
            disabled={!droneConnected || loading}
          >
            Go
          </button>
        </div>
      </div>
      {!droneConnected && (
        <p className="control-hint">Connect drone (Pixhawk via MAVLink) to enable controls</p>
      )}
    </div>
  )
}
