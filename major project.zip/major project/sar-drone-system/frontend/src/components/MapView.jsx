import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import './MapView.css'

const DEFAULT_CENTER = [28.6139, 77.2090] // Delhi - update as needed
const DEFAULT_ZOOM = 14

export function MapView({ telemetry, alerts }) {
  const mapRef = useRef(null)
  const mapInstanceRef = useRef(null)
  const droneMarkerRef = useRef(null)
  const alertMarkersRef = useRef([])

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return
    const map = L.map(mapRef.current).setView(DEFAULT_CENTER, DEFAULT_ZOOM)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
    }).addTo(map)
    mapInstanceRef.current = map
    return () => {
      map.remove()
      mapInstanceRef.current = null
    }
  }, [])

  // Update drone marker
  useEffect(() => {
    const map = mapInstanceRef.current
    if (!map || !telemetry) return
    const { latitude, longitude } = telemetry
    if (!latitude || !longitude) return

    const icon = L.divIcon({
      className: 'drone-marker',
      html: `<div class="drone-icon">✈</div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    })

    if (droneMarkerRef.current) {
      droneMarkerRef.current.setLatLng([latitude, longitude])
    } else {
      droneMarkerRef.current = L.marker([latitude, longitude], { icon }).addTo(map)
    }
  }, [telemetry])

  // Alert markers
  useEffect(() => {
    const map = mapInstanceRef.current
    if (!map) return

    alertMarkersRef.current.forEach((m) => m.remove())
    alertMarkersRef.current = []

    alerts.forEach((a) => {
      const lat = a.latitude ?? a.detections?.[0]?.latitude
      const lon = a.longitude ?? a.detections?.[0]?.longitude
      if (lat == null || lon == null) return
      const icon = L.divIcon({
        className: 'alert-marker',
        html: `<div class="alert-icon">⚠</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      })
      const m = L.marker([lat, lon], { icon }).addTo(map)
      m.bindPopup(a.message || 'Victim detected')
      alertMarkersRef.current.push(m)
    })
  }, [alerts])

  // Center map on drone when we have position
  useEffect(() => {
    const map = mapInstanceRef.current
    if (!map || !telemetry?.latitude || !telemetry?.longitude) return
    map.setView([telemetry.latitude, telemetry.longitude], map.getZoom())
  }, [telemetry?.latitude, telemetry?.longitude])

  return (
    <div className="map-container">
      <div ref={mapRef} className="map" />
    </div>
  )
}
