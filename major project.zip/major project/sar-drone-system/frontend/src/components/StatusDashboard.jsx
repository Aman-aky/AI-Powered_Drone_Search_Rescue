import './StatusDashboard.css'

export function StatusDashboard({ telemetry, droneConnected }) {
  const battery = telemetry?.battery_percent ?? null
  const batteryHealth = battery != null
    ? battery >= 60 ? 'good' : battery >= 25 ? 'warning' : 'critical'
    : null

  const items = [
    { label: 'Latitude', value: telemetry?.latitude?.toFixed(6) ?? '—', unit: '°' },
    { label: 'Longitude', value: telemetry?.longitude?.toFixed(6) ?? '—', unit: '°' },
    { label: 'Altitude', value: telemetry?.altitude?.toFixed(1) ?? '—', unit: 'm' },
    { label: 'Heading', value: telemetry?.heading?.toFixed(0) ?? '—', unit: '°' },
    { label: 'Speed', value: telemetry?.speed?.toFixed(1) ?? '—', unit: 'm/s' },
    { label: 'Mode', value: telemetry?.flight_mode ?? '—', unit: '' },
  ]

  return (
    <div className="status-dashboard">
      <div className={`connection-badge ${droneConnected ? 'connected' : ''}`}>
        {droneConnected ? 'Drone connected' : 'Drone disconnected'}
      </div>

      <div className="battery-health">
        <span className="battery-label">Battery Health</span>
        <div className="battery-container">
          <div
            className={`battery-bar ${batteryHealth || ''}`}
            style={{ width: battery != null ? `${Math.max(0, Math.min(100, battery))}%` : '0%' }}
          />
          <span className="battery-value font-mono">
            {battery != null ? `${battery.toFixed(0)}%` : '—'}
          </span>
        </div>
        {batteryHealth && (
          <span className={`battery-status ${batteryHealth}`}>
            {batteryHealth === 'good' && 'Good'}
            {batteryHealth === 'warning' && 'Low - Return soon'}
            {batteryHealth === 'critical' && 'Critical - Land now'}
          </span>
        )}
      </div>

      <div className="status-grid">
        {items.map(({ label, value, unit }) => (
          <div key={label} className="status-item">
            <span className="label">{label}</span>
            <span className="value font-mono">{value}{unit}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
