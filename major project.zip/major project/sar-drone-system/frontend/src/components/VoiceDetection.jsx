import { useState, useEffect, useCallback } from 'react'
import './VoiceDetection.css'

const KEYWORDS = ['help', 'sos', 'rescue', 'emergency', 'save', 'injured', 'stuck', 'danger', 'fire', 'water', 'hewlp', 'halp', 'hep', 'someone']

export function VoiceDetection({ onVoiceAlert }) {
  const [listening, setListening] = useState(false)
  const [status, setStatus] = useState('idle')
  const [lastHeard, setLastHeard] = useState('')

  const checkTranscript = useCallback((transcript) => {
    const lower = transcript.toLowerCase()
    for (const kw of KEYWORDS) {
      if (lower.includes(kw)) {
        return { matched: true, keyword: kw }
      }
    }
    return { matched: false }
  }, [])

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      setStatus('unsupported')
      return
    }

    const recognition = new SpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = 'en-US'
    recognition.maxAlternatives = 1

    recognition.onresult = (event) => {
      const results = Array.from(event.results)
      let transcript = ''
      for (const r of results) {
        const t = (r[0] && r[0].transcript) || ''
        transcript += t
        if (r.isFinal && t.trim()) {
          const { matched, keyword } = checkTranscript(t)
          if (matched) {
            onVoiceAlert?.({ type: 'voice_detected', keyword, transcript: t, severity: 'high' })
            setStatus('detected')
            setTimeout(() => setStatus('listening'), 2000)
          }
        }
      }
      setLastHeard(transcript.slice(-120))
    }

    recognition.onerror = (e) => {
      if (e.error === 'not-allowed') setStatus('denied')
      else setStatus('listening')
    }

    recognition.onend = () => {
      if (listening) setTimeout(() => { try { recognition.start() } catch (_) {} }, 100)
    }

    if (listening) {
      recognition.start()
      setStatus('listening')
    } else {
      recognition.stop()
      setStatus('idle')
    }

    return () => recognition.stop()
  }, [listening, checkTranscript, onVoiceAlert])

  const toggleListening = () => {
    if (status === 'unsupported' || status === 'denied') return
    setListening((v) => !v)
  }

  if (status === 'unsupported') {
    return (
      <div className="voice-detection">
        <p className="voice-unsupported">Voice detection not supported in this browser. Use Chrome/Edge.</p>
      </div>
    )
  }

  if (status === 'denied') {
    return (
      <div className="voice-detection">
        <p className="voice-denied">Microphone access denied. Enable it to detect voice alerts.</p>
      </div>
    )
  }

  return (
    <div className="voice-detection">
      <div className="voice-header">
        <button
          className={`voice-btn ${listening ? 'active' : ''}`}
          onClick={toggleListening}
          title={listening ? 'Stop listening' : 'Start listening for help/SOS'}
        >
          {listening ? '🔴 Listening' : '🎤 Start Voice Detection'}
        </button>
        <span className="voice-status">
          {status === 'listening' && 'Listening for: help, SOS, rescue...'}
          {status === 'detected' && '⚠ Alert detected!'}
          {status === 'idle' && 'Click to start'}
        </span>
      </div>
      {lastHeard && (
        <p className="voice-transcript">"{lastHeard}"</p>
      )}
    </div>
  )
}
