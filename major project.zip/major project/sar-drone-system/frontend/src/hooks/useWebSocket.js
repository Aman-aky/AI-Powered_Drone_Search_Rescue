import { useState, useCallback, useRef } from 'react'

export function useWebSocket(url, onMessage) {
  const [isConnected, setIsConnected] = useState(false)
  const wsRef = useRef(null)
  const reconnectRef = useRef(null)

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return

    const ws = new WebSocket(url)
    wsRef.current = ws

    ws.onopen = () => {
      setIsConnected(true)
      if (reconnectRef.current) {
        clearInterval(reconnectRef.current)
        reconnectRef.current = null
      }
    }

    ws.onclose = () => {
      setIsConnected(false)
      if (!reconnectRef.current) {
        reconnectRef.current = setInterval(() => connect(), 3000)
      }
    }

    ws.onerror = () => {
      ws.close()
    }

    ws.onmessage = (event) => {
      if (typeof onMessage === 'function') {
        onMessage(event.data)
      }
    }
  }, [url, onMessage])

  const disconnect = useCallback(() => {
    if (reconnectRef.current) {
      clearInterval(reconnectRef.current)
      reconnectRef.current = null
    }
    if (wsRef.current) {
      wsRef.current.close()
      wsRef.current = null
    }
    setIsConnected(false)
  }, [])

  return { connect, disconnect, isConnected }
}
